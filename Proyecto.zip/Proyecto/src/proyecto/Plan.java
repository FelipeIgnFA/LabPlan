
package proyecto;

public class Plan {
     private int valorMinuto;
    private int valorMantencion;
    private int cantidadCliente;
    
    public Plan(int valorMinuto, int valorMantencion, int cantidadCliente){
        this.valorMinuto=valorMinuto;
        this.valorMantencion=valorMantencion;
        this.cantidadCliente=cantidadCliente;
                

        } 

    public int GetValorMinuto() {
        return valorMinuto;
    }

    public void SetValorMinuto(int valorMinuto) {
        this.valorMinuto = valorMinuto;
    }

    public int GetValorMantencion() {
        return valorMantencion;
    }

    public void SetValorMantencion(int valorMantencion) {
        this.valorMantencion = valorMantencion;
    }

    public int GetCantidadCliente() {
        return cantidadCliente;
    }

    public void SetCantidadCliente(int cantidadCliente) {
        this.cantidadCliente = cantidadCliente;
    }




}
    

