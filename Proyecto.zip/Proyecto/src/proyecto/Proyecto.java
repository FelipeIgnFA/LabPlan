
package proyecto;
import java.util.Scanner;

public class Proyecto {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        Plan p = new Plan(80, 15000,0);
        Plan n = new Plan(120,7000,0 );
        int i= 0;
        int cantp = p.GetCantidadCliente();
        int cantn = n.GetCantidadCliente();
        
        do {
            

            int d;

            do {

                System.out.println("Bienvenido, que plan desea elegir?");

                System.out.println("(1)Plan Preferencial  $15000, $80 min por conexion");

                System.out.println("(2)Plan Normal $7000, $120 min por conexion");

                d =input.nextInt();

            }while ((d < 1)||(d >2));
            if (d==1){
                System.out.println("Cuantos minutos estuvo utilizandolo?");
                Cliente o = new Cliente ("Preferencial",input.nextInt());
                int calculo = p.GetValorMantencion() + (o.GetMinutoConexion() * p.GetValorMinuto()) ;
                System.out.println("Escogio el plan preferencial, estuvo "+ o.GetMinutoConexion() +" minuto/os utilizandolo");
                System.out.println("Por lo que tiene que pagar un monto de "+calculo);

                cantp ++;



            }
            else{
                System.out.println("Cuantos minutos estuvo utilizandolo?");
                Cliente u = new Cliente ("Preferencial",input.nextInt());
                int calculo2 = n.GetValorMantencion() + (u.GetMinutoConexion() * n.GetValorMinuto()) ;
                System.out.println("Escogio el plan normal, estuvo "+ u.GetMinutoConexion() +" minuto/os utilizandolo");
                System.out.println("Por lo que tiene que pagar un monto de "+calculo2);

                cantn ++;
            }


            System.out.println("La cantidad de clientes preferenciales es de " + cantp );
            System.out.println("La cantidad de clientes normales es de " + cantn );
            
            System.out.println("");
            
            System.out.println("Desea continuar? (1)Si  (2)No" );
            int bucle= input.nextInt();
            
                if (bucle ==1){
                    System.out.println("");
                }
                else if (bucle ==2){
                    i ++;
                    System.out.println("Que tenga buen dia");
                }
        }while(i == 0);    
            
            
    }
    
}
