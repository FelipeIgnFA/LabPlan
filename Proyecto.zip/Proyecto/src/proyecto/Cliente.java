
package proyecto;

public class Cliente {
    private String tipoPlan;
    private int minutoConexion;

    
    public Cliente(String tipoPlan , int minutoConexion){
        this.tipoPlan = tipoPlan;
        this.minutoConexion=minutoConexion;
        
        }
    
    public String GetTipoPlan(){
        return tipoPlan;
    }
      
    public void SetTipoPlan(String tipoPlan){
        this.tipoPlan=tipoPlan;        
    }
    public int GetMinutoConexion(){
        return minutoConexion;
    }
      
    public void SetMinutoConexion(int minutoConexion){
        this.minutoConexion=minutoConexion;      
        
     
    }    

}
    

